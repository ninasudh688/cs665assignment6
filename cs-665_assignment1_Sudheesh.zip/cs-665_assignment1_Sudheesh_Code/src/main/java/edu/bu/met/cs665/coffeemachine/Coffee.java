/**
 * Name: Nina Sudheesh
 * Course: CS-665 Software Designs & Patterns
 * Date: 09/26/2024
 * File Name: Coffee.java
 * Description:This class is responsible for the methods/attributes of a Coffee.
 */

package edu.bu.met.cs665.coffeemachine;

public class Coffee extends Beverage {
  /**
   * This is Coffee class which  is responsible for representing a Coffee.
   * Coffee is type of Beverage and why its child class of Beverage class
   */
  private String roastType;

  /**
   * Create a Coffee object using size,price,condimentHandler,& roastType parameters.
   *
   * @param beverageSize     size of drink as string
   * @param basePrice        price of base drink as double.
   * @param condimentHandler condimentHandler
   * @param roastType        coffee roast type
   */
  public Coffee(String beverageSize, double basePrice, CondimentHandler
      condimentHandler, String roastType) {
    super(beverageSize, basePrice, condimentHandler);
    this.roastType = roastType;
  }

  /**
   * Brew method that all coffees classes use.
   *
   * @return String message about coffee brewed.
   */
  @Override
  public String brew() {
    return "Brewing coffee beans: ";
  }

  /**
   * Get method that to get roast type of coffee.
   *
   * @return roastType  string roast type of the coffee being made.
   */
  public String getRoastType() {
    return roastType;
  }

  /**
   * Set method that to set roast type of coffee.
   *
   * @param roastType roast type of the coffee beans being made.
   */
  public void setRoastType(String roastType) {
    this.roastType = roastType;
  }
}


