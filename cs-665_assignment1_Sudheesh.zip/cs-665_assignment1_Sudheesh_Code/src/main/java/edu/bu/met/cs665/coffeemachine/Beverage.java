/**
 * Name: Nina Sudheesh
 * Course: CS-665 Software Designs & Patterns
 * Date: 09/26/2024
 * File Name: Beverage.java
 * Description: This class is responsible for methods/attributes of a Beverage.
 */

package edu.bu.met.cs665.coffeemachine;

public abstract class Beverage {
  /**
   * This is the Beverage class.
   * This class is responsible for representing a Beverage.
   */
  private String beverageSize;
  private double basePrice;
  protected CondimentHandler condimentHandler; // Composition

  /**
   * Create a Beverage object using size, price,and condiment handler.
   *
   * @param beverageSize     size of drink as string
   * @param basePrice        price oof base drink  as double
   * @param condimentHandler condimentHandler
   */
  public Beverage(String beverageSize, double basePrice,
                  CondimentHandler condimentHandler) {
    this.beverageSize = beverageSize;
    this.basePrice = basePrice;
    this.condimentHandler = condimentHandler;
  }

  /**
   * Abstract brew method that all beverages use.
   *
   * @return String message about beverage brewed.
   */
  public abstract String brew();

  /**
   * Calculates final price with condiment price charges included.
   *
   * @param condiment the milk pr sugar to be added tp drink.
   */
  public void addCondiments(Condiment condiment) {
    condimentHandler.addCondiments(condiment);
  }

  /**
   * Calculates final price with condiment price charges included.
   *
   * @return the base cost of drink + condiment total price.
   */
  public double calculateFinalPrice() {
    return basePrice + condimentHandler.calculateCondimentPrice();
  }

  /**
   * Getter method for Condiments.
   *
   * @return all the condiments
   */
  public String getCondimentDetails() {
    return condimentHandler.getCondiments();
  }

  /**
   * Getter method for beverage base cost.
   *
   * @return the base cost of drink
   */
  public double getBasePrice() {
    return basePrice;
  }

  /**
   * Getter method for Beverage size.
   *
   * @return the size of the drink.
   */
  public String getBeverageSize() {
    return beverageSize;
  }

  /**
   * Setter method for Beverage's size.
   *
   * @param beverageSize size assigned to the drink
   */
  public void setBeverageSize(String beverageSize) {
    this.beverageSize = beverageSize;
  }

  /**
   * Setter method for base price of beverage.
   *
   * @param basePrice The base price to assign to this beverage.
   */
  public void setBasePrice(double basePrice) {
    this.basePrice = basePrice;
  }

  /**
   * Getter method for instance of condiment handler.
   *
   * @return t
   */
  public CondimentHandler getCondimentHandler() {
    return condimentHandler;
  }

  /**
   * Setter method for base price of beverage.
   *
   * @param condimentHandler set instance of condiment handler.
   */
  public void setCondimentHandler(CondimentHandler condimentHandler) {
    this.condimentHandler = condimentHandler;
  }
}
