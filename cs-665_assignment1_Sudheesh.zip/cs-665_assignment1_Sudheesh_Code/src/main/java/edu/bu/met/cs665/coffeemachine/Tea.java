/**
 * Name: Nina Sudheesh
 * Course: CS-665 Software Designs & Patterns
 * Date: 09/26/2024
 * File Name: Tea.java
 * Description: This class is responsible for the methods and attributes of a Tea.
 */

package edu.bu.met.cs665.coffeemachine;

public class Tea extends Beverage {
  /**
   * This is Tea class which  is responsible for representing a Tea.
   * Tea is type of Beverage and why its child class of Beverage class.
   */
  private boolean isCaffeinated;

  /**
   * Create a Tea object using size,price,condimentHandler,& isCaffeinated parameters.
   *
   * @param beverageSize     size of drink as string
   * @param basePrice        price of base drink as double.
   * @param condimentHandler condimentHandler
   * @param isCaffeinated    if tea is caffeinated
   */
  public Tea(String beverageSize, double basePrice,
             CondimentHandler condimentHandler, boolean isCaffeinated) {
    super(beverageSize, basePrice, condimentHandler);
    this.isCaffeinated = isCaffeinated;
  }

  /**
   * Brew method for steeping the tea.
   */
  @Override
  public String brew() {
    return "Steeping the tea: ";
  }

  /**
   * Boolean method for beverage base cost.
   *
   * @return isCaffeinated checks if tea is caffeinated or not
   */
  public boolean isCaffeinated() {
    return isCaffeinated;
  }
}
