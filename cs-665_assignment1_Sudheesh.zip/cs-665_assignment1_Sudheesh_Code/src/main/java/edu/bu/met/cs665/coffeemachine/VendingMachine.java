/**
 * Name: Nina Sudheesh
 * Course: CS-665 Software Designs & Patterns
 * Date: 09/26/2024
 * File Name: VendingMachine.java
 * Description: This class is responsible for methods/attributes of a Vending Machine.
 */

package edu.bu.met.cs665.coffeemachine;

import java.util.ArrayList;
import java.util.List;

public class VendingMachine {
  /**
   * This is VendingMachine class which is responsible for handling a Vending Machine operations.
   * It handles Beverage brewing and creating list of VendingMachine beverages.
   */

  private List<Beverage> availableBeverages;

  /**
   * Create a VendingMachine object that initializes list of available beverage.
   */
  public VendingMachine() {
    availableBeverages = new ArrayList<>();
  }

  /**
   * Method to add beverage to list of available beverages.
   *
   * @param beverage Beverage object to add.
   */
  public void addBeverage(Beverage beverage) {
    availableBeverages.add(beverage);
  }

  /**
   * Method to do all beverage brewing,creation, and pricing.
   *
   * @param beverage Beverage object to add.
   * @param condiment Condiment object to add milk/sugar units.
   */
  public void brewBeverage(Beverage beverage, Condiment condiment) {
    String brewingMessage = beverage.brew(); // Get the brewing message
    System.out.println(brewingMessage);
    beverage.addCondiments(condiment);
    System.out.println("Final price: $" + beverage.calculateFinalPrice());
  }

  /**
   * Method to display the list of available beverages with prices as Menu.
   */
  public void displayAvailableBeverages() {
    System.out.println("\nAll Beverages Available: ");
    for (Beverage beverage : availableBeverages) {
      System.out.println(beverage.getClass().getSimpleName()
          + ": $" + beverage.getBasePrice());
    }
  }
}
